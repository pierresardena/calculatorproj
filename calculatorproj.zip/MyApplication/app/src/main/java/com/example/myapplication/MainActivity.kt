package com.example.myapplication


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private var currentNumber: String = ""
    private var result: Double = 0.0
    private var lastOperator: Char = ' '

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.inptnum)
        val btnEquals: ImageButton = findViewById(R.id.buttonEqual)

        val numberzero: ImageButton = findViewById(R.id.numberzero)
        val numberone: ImageButton = findViewById(R.id.numberone)
        val numbertwo: ImageButton = findViewById(R.id.numbertwo)
        val numberthree: ImageButton = findViewById(R.id.numberthree)
        val numberfour: ImageButton = findViewById(R.id.numberfour)
        val numberfive: ImageButton = findViewById(R.id.numberfive)
        val numbersix: ImageButton = findViewById(R.id.numbersix)
        val numberseven: ImageButton = findViewById(R.id.numberseven)
        val numbereight: ImageButton = findViewById(R.id.numbereight)
        val numbernine: ImageButton = findViewById(R.id.numbernine)
        val decimal: ImageButton = findViewById(R.id.decimal)

        val buttonClear: ImageButton = findViewById(R.id.imageButton17)
        val buttonPlus: ImageButton = findViewById(R.id.imageButton4)
        val buttonMinus: ImageButton = findViewById(R.id.imageButton5)
        val buttonMultiply: ImageButton = findViewById(R.id.imageButton6)
        val buttonDivide: ImageButton = findViewById(R.id.imageButton7)
        val buttonPercent: ImageButton = findViewById(R.id.imageButton19)
        val buttonPlusMinus: ImageButton = findViewById(R.id.imageButton18)

        numberzero.setOnClickListener { appendNumber("0") }
        numberone.setOnClickListener { appendNumber("1") }
        numbertwo.setOnClickListener { appendNumber("2") }
        numberthree.setOnClickListener { appendNumber("3") }
        numberfour.setOnClickListener { appendNumber("4") }
        numberfive.setOnClickListener { appendNumber("5") }
        numbersix.setOnClickListener { appendNumber("6") }
        numberseven.setOnClickListener { appendNumber("7") }
        numbereight.setOnClickListener { appendNumber("8") }
        numbernine.setOnClickListener { appendNumber("9") }
        decimal.setOnClickListener { appendNumber(".") }

        buttonPercent.setOnClickListener {
            if (currentNumber.isNotEmpty()) {
                try {
                    // Convert current number to a percentage
                    val currentValue = currentNumber.toDouble() / 100
                    currentNumber = currentValue.toString()

                    // If an operator is already selected, apply the percentage to the result
                    if (lastOperator != ' ') {
                        when (lastOperator) {
                            '+' -> result += currentValue
                            '-' -> result -= currentValue
                            '*' -> result *= currentValue
                            '/' -> {
                                if (currentValue != 0.0) {
                                    result /= currentValue
                                } else {
                                    textView.text = "Error"
                                    currentNumber = ""
                                    return@setOnClickListener
                                }
                            }
                        }
                        // Reset current number after applying the percentage
                        currentNumber = ""
                        textView.text = result.toString().removeSuffix(".0")
                    } else {
                        // If no operator is selected, just display the percentage value
                        textView.text = currentNumber
                    }

                } catch (e: Exception) {
                    // Handle any errors and prevent the app from crashing
                    textView.text = "Error"
                    currentNumber = ""
                }
            }
        }

        // Function to perform operations


// Arithmetic operation buttons
        buttonPlus.setOnClickListener {
            performOperation('+')
        }

        buttonMinus.setOnClickListener {
            performOperation('-')
        }

        buttonMultiply.setOnClickListener {
            performOperation('*')
        }

        buttonDivide.setOnClickListener {
            performOperation('/')
        }

        buttonClear.setOnClickListener {
            currentNumber = ""
            result = 0.0
            lastOperator = ' '
            textView.text = "0"
        }

        buttonPlusMinus.setOnClickListener {
            currentNumber = if (currentNumber.startsWith("-")) {
                currentNumber.removePrefix("-")
            } else {
                "-$currentNumber"
            }
            textView.text = currentNumber
        }

        buttonPercent.setOnClickListener {
            if (currentNumber.isNotEmpty()) {
                currentNumber = (currentNumber.toDouble() / 100).toString()
                textView.text = currentNumber
            }
        }

        btnEquals.setOnClickListener {
            if (currentNumber.isNotEmpty()) {
                when (lastOperator) {
                    '+' -> result += currentNumber.toDouble()
                    '-' -> result -= currentNumber.toDouble()
                    '*' -> result *= currentNumber.toDouble()
                    '/' -> {
                        if (currentNumber.toDouble() != 0.0) {
                            result /= currentNumber.toDouble()
                        } else {
                            // Handle division by zero
                            textView.text = "Error"
                            currentNumber = ""
                            return@setOnClickListener
                        }
                    }
                }

                // Reset the operator and clear current input
                lastOperator = ' '
                currentNumber = ""

                // Display the result, formatted to remove unnecessary decimals
                textView.text = if (result % 1 == 0.0) {
                    result.toInt().toString()
                } else {
                    result.toString()
                }
            }
        }

    }
    private fun performOperation(operator: Char) {
        if (currentNumber.isNotEmpty()) {
            try {
                val currentValue =
                    currentNumber.toDouble() // Convert the current input to a double

                // If there's no previous operator, initialize result with the current input
                if (lastOperator == ' ') {
                    result = currentValue
                } else {
                    // Perform the previous operation
                    when (lastOperator) {
                        '+' -> result += currentValue
                        '-' -> result -= currentValue
                        '*' -> result *= currentValue
                        '/' -> {
                            if (currentValue != 0.0) {
                                result /= currentValue
                            } else {
                                // Handle division by zero error
                                textView.text = "Cannot divide by zero"
                                currentNumber = ""
                                return
                            }
                        }
                    }
                }
                lastOperator = operator // Update the last operator to the newly selected one
                currentNumber = "" // Clear the current number for new input
                textView.text = if (result % 1 == 0.0) result.toInt()
                    .toString() else result.toString() // Display the result correctly

            } catch (e: NumberFormatException) {
                // Handle any conversion errors
                textView.text = "Error"
                currentNumber = ""
            }
        } else {
            // If no current number is entered, only update the last operator
            lastOperator = operator
        }
    }
        private fun appendNumber(number: String) {
            currentNumber += number
            textView.text = currentNumber
        }

    }
